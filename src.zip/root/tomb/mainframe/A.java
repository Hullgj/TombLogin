/*
 * Decompiled with CFR 0_118.
 * 
 * Could not load the following classes:
 *  javafx.scene.control.Alert
 *  javafx.scene.control.Alert$AlertType
 *  javafx.scene.media.Media
 *  javafx.scene.media.MediaPlayer
 *  javafx.util.Duration
 */
package root.tomb.mainframe;

import java.io.File;
import java.net.URI;
import java.util.Map;
import java.util.TreeMap;
import javafx.scene.control.Alert;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import root.tomb.mainframe.C;
import root.tomb.mainframe.N2;

public class A {
    public static final A am = new A();
    private MediaPlayer a;
    private Map<String, Media> d;
    private boolean t = true;
    private double p;
    private boolean m;
    private boolean failed;

    private A() {
        try {
            this.d = new TreeMap<String, Media>();
            C.m.o("Loading music from: " + new File(new StringBuilder(String.valueOf(C.y)).append(File.separator).append("main.mp3").toString()).getAbsolutePath());
            this.d.put("main", new Media(new File(String.valueOf(C.y) + File.separator + "main.mp3").toURI().toString()));
            this.p = 0.05;
            this.m = false;
            this.failed = false;
        }
        catch (Exception e) {
            N2.iu("Warning", "Music player error", "We can continue, but if you want to fix this then be sure to install the package 'ffmpeg' on linux distros.", Alert.AlertType.WARNING);
            this.failed = true;
        }
    }

    public void o(String t) {
        if (this.failed) {
            return;
        }
        try {
            C.m.o("Playing music: " + t);
            if (this.d.containsKey(t)) {
                Media hit = this.d.get(t);
                this.a(hit);
            } else {
                this.a(this.d.get("main"));
            }
        }
        catch (Exception e) {
            N2.iu("Warning", "Music player error", "We can continue, but if you want to fix this then be sure to install the package 'ffmpeg' on linux distros.", Alert.AlertType.WARNING);
            this.failed = true;
        }
    }

    private void a(Media hg) {
        if (this.a != null || !this.t) {
            C.m.o("Error, couldn't play music.");
            return;
        }
        this.a = new MediaPlayer(hg);
        this.a.setVolume(this.p);
        this.a.play();
        C.m.o("Playing music now. Volume: " + this.p);
        this.a.setOnEndOfMedia(new Runnable(){

            @Override
            public void run() {
                A.this.a.seek(Duration.ZERO);
            }
        });
    }

    public void v() {
        this.a.pause();
    }

    public boolean s(String m) {
        if (m == null || m.equalsIgnoreCase("NA")) {
            return false;
        }
        try {
            String a = new File(String.valueOf(C.y) + File.separator + m).toURI().toString();
            Media y = new Media(a);
            this.d.put(m, y);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean y() {
        return this.a.isMute();
    }

    public void q(boolean c) {
        if (this.failed) {
            return;
        }
        this.a.setMute(c);
        this.m = c;
    }

    public void h(double w) {
        this.a.setVolume(w);
        this.p = w;
    }

}

