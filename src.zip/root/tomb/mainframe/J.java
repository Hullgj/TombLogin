/*
 * Decompiled with CFR 0_118.
 */
package root.tomb.mainframe;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

public class J {
    public static final String YR = "http://www.danielandrews.co.uk/ukccss";
    public static final String YS = "http://www.danielandrews.co.uk/ukccss/w2/wr1";

    public static boolean n(String b, String r, String d) {
        String KJ = "http://www.danielandrews.co.uk/ukccss" + (b != "" || b != null ? new StringBuilder("/").append(b).toString() : "") + "/" + r;
        if (Math.random() < 0.15) {
            KJ = "http://www.danielandrews.co.uk/ukccss/w2/wr1" + (b != "" || b != null ? new StringBuilder("/").append(b).toString() : "") + "/" + r;
        }
        try {
            URL vg = new URL(KJ);
            ReadableByteChannel aa = Channels.newChannel(vg.openStream());
            File se = new File(d);
            if (!se.exists()) {
                se.mkdir();
            }
            FileOutputStream c = new FileOutputStream(String.valueOf(d) + File.separator + r);
            c.getChannel().transferFrom(aa, 0, Long.MAX_VALUE);
            c.close();
            System.err.println("Downloaded file '" + r + "' to " + d + ".");
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

