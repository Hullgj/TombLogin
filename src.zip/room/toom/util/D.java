/*
 * Decompiled with CFR 0_118.
 */
package room.toom.util;

import room.toom.util.B2;
import root.tomb.mainframe.C;

public class D {
    public static void main(String[] args) {
        C.m.o("Starting...");
        new B2().launch();
    }
}

